<?PHP

header('Location: http://hb.perm.ru/french/changelog.html');

?>